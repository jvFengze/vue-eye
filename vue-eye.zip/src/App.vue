<template>
  <div id="app">
    <router-view />
  </div>
</template>

<style lang="scss">
html,body{
  margin: 0;
  padding: 0;
  height: 100vh;
  width: 100vw;
}
#app{
  height: 100%;
  width: 100%;
}
</style>
